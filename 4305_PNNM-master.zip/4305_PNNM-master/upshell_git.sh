#ssh-keygen -t rsa -b 4096 -C "thai.itplus@gmail.com"
#/home/kids/.ssh/id_rsa

path="https://github.com/balau123/4305_PNNM.git"
username="balau123"
email="thai.itplus@gmail.com"

git config --global user.name $username
git config --global user.email $email
git config --global color.ui auto

clear
work_path="/home/kids/Desktop/4305_PNNM"
echo "username: " $username
echo "Email: " $email
echo "Path: "$path

echo
echo "LIST FILE"
echo
ls -lh
echo

git config --global core.editor "$work_path"
#git init



echo "ADD FILE NAME TO PUSH"
echo "c - continue"
echo "* - SELECT ALL"

#add file

echo "x: exit"
echo
echo
while [[ $file_name != 'c' ]]
do
    echo "Enter filename: "
    read file_name

	if [[ $file_name == '*' ]]; then
		echo "Select all"
		git  add *
	        echo "c: continue"
	else

	if [[ $file_name != 'c' ]]; then
		echo "[add] $file_name"
		echo "c: continue"
		git add "$file_name"
	fi
	fi

done

echo "commit content: "
read commit
echo
echo "Coomit content: $commit"
echo "PATH: $path"
echo
echo "*** working"
echo

#git add *
git commit -m "$commit"
git remote remove origin
git remote add origin "$path"
#git pull origin master
git push origin master

echo
echo "DONE!!!"	
