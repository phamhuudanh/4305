clear
echo
echo "***HEllo $USER"
echo
echo "***Thu muc hien hanh"
pwd
echo
echo "***Liet ke file va thu muc"
ls -l
echo
echo "***Ngay gio hien tai"
echo "$(date)"
