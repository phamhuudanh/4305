#ifndef _tinhtoan_H
#define _tinhtoan_H
int cong(int a, int b);
int tru(int a, int b);
int nhan(int a, int b);
float chia(int a, int b);
#endif
