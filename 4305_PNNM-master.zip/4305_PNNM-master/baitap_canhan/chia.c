#include "tinhtoan.h"

float chia(int a, int b)
{
	return (float)a/b;
}
