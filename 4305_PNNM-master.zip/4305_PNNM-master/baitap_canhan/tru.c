#include "tinhtoan.h"
int tru(int a, int b){
return a-b;
}
